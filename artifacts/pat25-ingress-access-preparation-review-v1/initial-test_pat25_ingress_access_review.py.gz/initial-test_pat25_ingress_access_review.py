"""Independent offline/mock PAT25 ingress runner checks; no native/patient runs."""
import copy
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import diagnose_pat25_ingress_access as d


def test_observer_exception_cannot_resume_a_later_unguarded_phase():
    namespace = {"__name__": "resectionlab.native_spatial_task", "body_ran": False}
    exec("def step():\n    global body_ran\n    body_ran = True\n", namespace)
    trace = d.InitialOnlyTrace()
    with trace:
        trace.begin("original")
        with pytest.raises(RuntimeError, match="prohibited"):
            namespace["step"]()
        assert namespace["body_ran"] is False
        assert sys.getprofile() is None  # CPython really removed the failing callback.
        trace.end()
        with pytest.raises(RuntimeError):
            trace.begin("screened_selected")
    assert sys.getprofile() is None


def parent_fixture(monkeypatch, tmp_path):
    state = {"seconds": 0., "unchanged_calls": 0, "commands": [], "caps": []}
    monkeypatch.setattr(d, "time", SimpleNamespace(perf_counter=lambda: state["seconds"]))
    manifest, release, output = tmp_path / "manifest.json", tmp_path / "release.json", tmp_path / "attempt"
    manifest.write_text("manifest-bound-to-parent")
    release.write_text("release-bound-to-parent")
    digests = {str(manifest): "1" * 64, str(release): "2" * 64}
    monkeypatch.setattr(d, "sha256", lambda path: digests.get(str(Path(path)), "3" * 64))
    def preflight(*args, **kwargs):
        state["seconds"] += 30.
        if "check" in kwargs:
            kwargs["check"]()
        return {}, {}, dict(digests), {"source_commit": "a" * 40}
    monkeypatch.setattr(d, "preflight", preflight)
    def supervisor(command, destination, settings, digest):
        state["commands"].append(command)
        state["caps"].append(settings)
        state["seconds"] += 140.
        d.write_json(destination / "receipt.json", {"version": d.VERSION, "subject": d.SUBJECT,
            "status": "complete", "inputs_unchanged": True})
        return {"status": "complete"}
    monkeypatch.setattr(d, "supervise_worker", supervisor)
    monkeypatch.setattr(d, "unchanged", lambda bound: True)
    return manifest, release, output, state, digests


def test_full_attempt_budget_includes_last_input_hash_and_acceptance_publication(monkeypatch, tmp_path):
    manifest, release, output, state, _ = parent_fixture(monkeypatch, tmp_path)
    real_write = d.write_json
    def unchanged(bound):
        state["unchanged_calls"] += 1
        if state["unchanged_calls"] == 2:
            state["seconds"] += 20.  # Final encoded-input/source hashing costs real time.
        return True
    def write(path, payload):
        if Path(path).name == "acceptance.json":
            state["seconds"] += 10.  # Final serialization/publication also belongs to lifecycle.
        return real_write(path, payload)
    monkeypatch.setattr(d, "unchanged", unchanged)
    monkeypatch.setattr(d, "write_json", write)
    result = d.run(manifest, release, output)
    assert state["seconds"] >= 190.
    assert result["status"] != "complete", "Late hashing/publication exceeded180s but was accepted"


def test_parent_binds_manifest_and_release_bytes_into_worker_invocation(monkeypatch, tmp_path):
    manifest, release, output, state, digests = parent_fixture(monkeypatch, tmp_path)
    d.run(manifest, release, output)
    assert len(state["commands"]) == 1
    command = state["commands"][0]
    assert digests[str(manifest)] in command, "Worker must receive the parent's exact declaration byte identity"
    assert digests[str(release)] in command, "Worker must receive the parent's exact release byte identity"
