"""Independent offline launcher controls; no actual image or inspector call."""
from types import SimpleNamespace

import pytest

from test_rhuh_single_image_inspection_launch import mod


@pytest.mark.parametrize("kind", ["empty", "unrelated_only", "child_only", "duplicate_launcher"])
def test_rss_requires_one_live_launcher_measurement(monkeypatch, kind):
    """Missing RSS must remain unavailable rather than becoming zero."""
    launcher = mod.os.getpid()
    streams = {
        "empty": b"",
        "unrelated_only": b"900001 900001 33\n",
        "child_only": b"900002 812345 17\n",
        "duplicate_launcher": f"{launcher} 1 13\n{launcher} 1 13\n".encode(),
    }
    monkeypatch.setattr(mod.subprocess, "run", lambda *args, **kwargs: SimpleNamespace(stdout=streams[kind]))
    with pytest.raises(mod.Rejected):
        mod.sample_rss(812345)


def test_exited_child_group_can_leave_only_launcher_snapshot(monkeypatch):
    raw = f"{mod.os.getpid()} 1 23\n900001 900001 9999\n".encode()
    monkeypatch.setattr(mod.subprocess, "run", lambda *args, **kwargs: SimpleNamespace(stdout=raw))
    assert mod.sample_rss(812345) == 23 * 1024
