"""Independent analytical runner controls; never reads or fits clinical CSV rows."""
import json
import os
from pathlib import Path
import time
import warnings

import numpy as np
import pytest

from scripts import run_rhuh_preoperative_baseline as runner

ROOT = Path(__file__).resolve().parents[1]


def study():
    return json.loads((ROOT / runner.DECLARATION_PATH).read_text())


def test_convergence_warning_subclass_cannot_be_marked_converged():
    from sklearn.exceptions import ConvergenceWarning
    from sklearn.preprocessing import StandardScaler

    class DerivedConvergenceWarning(ConvergenceWarning):
        pass

    class Model:
        def fit(self, X, y):
            self.coef_ = np.zeros((1, X.shape[1]))
            self.intercept_ = np.zeros(1)
            self.n_iter_ = np.ones(1, dtype=int)
            self.classes_ = np.array([0, 1])
            warnings.warn("constructed convergence failure", DerivedConvergenceWarning)

        def predict_proba(self, X):
            return np.tile([.5, .5], (len(X), 1))

    rows = []
    counts = {"attempted": 0, "completed": 0}
    with pytest.raises(RuntimeError, match="convergence"):
        runner.loo(np.arange(12.).reshape(6, 2), np.array([0, 1, 0, 1, 0, 1]),
                   [f"analytic-{i}" for i in range(6)], study(),
                   deadline=time.monotonic() + 10, counts=counts,
                   on_fold=rows.append, job="constructed-warning",
                   factory=lambda: (StandardScaler(), Model()))
    assert counts == {"attempted": 1, "completed": 0}
    assert len(rows) == 1 and rows[0]["status"] == "failed"


def test_runtime_refuses_numpy_from_outside_the_declared_interpreter(tmp_path, monkeypatch):
    dependency = json.loads((ROOT / "artifacts/rhuh-baseline-runtime-v1/receipt.json").read_text())
    foreign = tmp_path / "foreign_numpy_init.py"
    foreign.write_text("# constructed unrelated numerical source\n")
    monkeypatch.setattr(np, "__file__", str(foreign))
    for key in runner.THREADS:
        monkeypatch.setenv(key, "1")
    with pytest.raises(ValueError):
        runner.runtime_record({"dependency": dependency})


def test_constant_features_reduce_to_training_prevalence_without_penalized_intercept():
    X = np.tile([3., 9.], (6, 1))
    y = np.array([0, 0, 0, 1, 1, 1])
    rows = []
    counts = {"attempted": 0, "completed": 0}
    predictions = runner.loo(X, y, [f"analytic-{i}" for i in range(6)], study(),
        deadline=time.monotonic() + 10, counts=counts, on_fold=rows.append,
        job="constant-analytical-features", shadow_X=X.copy())
    expected = (3 - y) / 5
    for model in runner.MODELS:
        np.testing.assert_allclose(predictions[model], expected, rtol=0, atol=5e-7)
    assert counts == {"attempted": 12, "completed": 12}
    for row in rows:
        assert row["holdout_patient_id"] not in row["training_patient_ids"]
        for model, width in (("KPS", 1), ("KPS_CE_VOLUME", 2)):
            assert row["models"][model]["scaler_scale"] == [1.] * width
            assert row["models"][model]["coefficients"] == [[0.] * width]
            assert row["models"][model]["shadow_prediction_identical"]


def test_metrics_match_closed_form_and_declared_paired_sign():
    result = runner.metrics([0, 1, 0, 1], {
        "FOLD_PREVALENCE": [.5] * 4,
        "KPS": [.5] * 4,
        "KPS_CE_VOLUME": [.1, .2, .8, .9],
    })
    assert result["models"]["KPS_CE_VOLUME"]["brier"] == pytest.approx(.325)
    assert result["models"]["KPS_CE_VOLUME"]["roc_auc"] == .75
    assert result["paired_brier"]["KPS_CE_VOLUME_minus_KPS"] == pytest.approx(.075)
    assert result["models"]["KPS_CE_VOLUME"]["confusion"] == {"TN": 1, "FP": 1, "FN": 1, "TP": 1}
    assert result["models"]["KPS"]["negative_predictive_value"]["value"] is None
    assert result["confidence_intervals"] is None
    assert result["clinical_calibration_validated"] is False


def test_final_influence_failure_never_publishes_a_13_case_summary(tmp_path, monkeypatch):
    y = np.array([0] * 26 + [1] * 14)
    ids = [f"analytic-{i:02d}" for i in range(40)]
    data = {"X": np.ones((40, 2)), "y": y, "ids": ids,
            "categories": ["constructed"] * 40, "projection_hashes": ["constructed"] * 40}
    jobs = []

    def fake_loo(X, labels, kept_ids, config, *, counts, job, **kwargs):
        jobs.append(job)
        if job == "delete:" + ids[-1]:
            counts["attempted"] += 1
            raise RuntimeError("constructed final influence fit failure")
        counts["attempted"] += 2 * len(labels)
        counts["completed"] += 2 * len(labels)
        return {model: [.35] * len(labels) for model in runner.MODELS}

    monkeypatch.setattr(runner, "loo", fake_loo)
    with pytest.raises(RuntimeError, match="final influence"):
        runner.evaluate(data, data, study(), tmp_path, time.monotonic() + 15)
    state = json.loads((tmp_path / "state.json").read_text())
    assert state["status"] == "failed_or_incomplete"
    assert state["permutation"]["planned"] == state["permutation"]["completed"] == 99
    assert state["permutation"]["p_value"] == 1
    assert state["influence"]["planned"] == 14
    assert state["influence"]["completed"] == 13
    assert state["influence"]["summary"] is None
    assert state["fits"] == {"attempted": 9015, "completed": 9014}
    assert len(jobs) == 114
    lines = (tmp_path / "influence.jsonl").read_text().splitlines()
    assert len(lines) == 14
    assert json.loads(lines[-1])["status"] == "failed"
