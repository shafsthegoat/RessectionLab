"""Independent constructed-file controls; no solver or measured data access."""
import hashlib
import json

import pytest

from scripts import mechanics_hbe_access as access
from scripts import mechanics_hbe_backend as backend


LIBRARY_NAMES = {
    "install/bin/febio4",
    *(f"install/lib/lib{name}.dylib" for name in (
        "feamr", "febiofluid", "febiolib", "febiomech", "febiomix",
        "febioopt", "febioplot", "febiorve", "febioxml", "fecore",
        "feimglib", "numcore")),
}


def save(root, name, value):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    data = value if isinstance(value, bytes) else access.canonical_json(value)
    path.write_bytes(data)
    return {"path": name, "sha256": hashlib.sha256(data).hexdigest()}


def runtime_fixture(root, monkeypatch, *, library_names=LIBRARY_NAMES):
    """Toy non-executable bytes isolate manifest contracts, not runtime validity."""
    libraries = {name: save(root, backend.PREFIX + "/" + name,
                           ("constructed " + name).encode())["sha256"]
                 for name in library_names}
    patched = save(root, backend.PREFIX + "/source/NumCore/AccelerateSparseSolver.cpp",
                   b"constructed source, not a solver")
    monkeypatch.setattr(backend, "PATCHED_SOURCE_SHA", patched["sha256"])
    omp = save(root, backend.PREFIX + "/openmp/lib/libomp.dylib", b"constructed OpenMP")
    identity = {
        "source_commit": backend.UPSTREAM_COMMIT, "runtime_version": "4.13.0",
        "architecture": "arm64", "source_patch_sha256": backend.PATCH_SHA,
        "patched_source_sha256": patched["sha256"],
        "executable": str(root / backend.PREFIX / "install/bin/febio4"),
        "executable_sha256": libraries["install/bin/febio4"],
        "libraries": libraries,
        "private_openmp": {"path": str(root / omp["path"]), "sha256": omp["sha256"]},
    }
    return identity, save(root, "runtime.json", identity)


def test_control_pass_labels_without_execution_and_raw_evidence_are_rejected(tmp_path, monkeypatch):
    runtime_binding = {"path": "runtime.json", "sha256": "1" * 64}
    # The runtime layer is intentionally isolated: this must fail at controls.
    monkeypatch.setattr(backend, "verify_runtime_binding", lambda *args: {
        "runtime": {}, "prefix": str(tmp_path / backend.PREFIX), "inputs": {},
        "runtime_identity": runtime_binding,
    })
    profile = {"schema": "hbe-solver-backend-v1", "profile_id": backend.PROFILE_ID,
               "runtime_identity": runtime_binding}
    profile["patch_identity"] = save(tmp_path, "patch.json", {
        "source_commit": backend.UPSTREAM_COMMIT, "patched_sha256": backend.PATCHED_SOURCE_SHA,
        "patch_sha256": backend.PATCH_SHA, "changed_source_files": 1,
        "other_changes": False, "iterative_mode_allowed": False,
    })
    for name, status, field, cases in (
        ("hex8_controls", "passed_all_five_fixed_patch_controls", "rows", backend.HEX_CASES),
        ("tet10_mpc_controls", "three_actual_fixed_software_controls_passed", "case_rows", backend.TET_CASES),
    ):
        profile[name] = save(tmp_path, name + ".json", {
            "status": status, "solver_backend": "accelerate",
            "runtime_identity_sha256": runtime_binding["sha256"],
            "solver_invocations": len(cases),
            field: [{"case": name, "passed": True} for name in sorted(cases)],
            "stiffness_scaling": {"passed": True},
        })
    binding = save(tmp_path, "profile.json", profile)
    with pytest.raises(ValueError):
        backend.verify_profile(tmp_path, binding)


def test_runtime_cannot_omit_twelve_linked_library_bindings(tmp_path, monkeypatch):
    identity, binding = runtime_fixture(tmp_path, monkeypatch,
                                        library_names={"install/bin/febio4"})
    identity["status"] = "isolated_patched_runtime_built_pending_numerical_controls"
    binding = save(tmp_path, binding["path"], identity)
    with pytest.raises(ValueError):
        backend.verify_runtime_binding(tmp_path, binding)


def test_worker_candidate_is_not_parent_accepted_runtime(tmp_path, monkeypatch):
    identity, binding = runtime_fixture(tmp_path, monkeypatch)
    identity["status"] = "candidate_pending_parent_build_acceptance"
    binding = save(tmp_path, binding["path"], identity)
    with pytest.raises(ValueError):
        backend.verify_runtime_binding(tmp_path, binding)
