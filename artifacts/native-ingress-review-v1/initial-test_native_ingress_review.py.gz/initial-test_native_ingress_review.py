"""Independent small-grid ingress checks; never patient data or stroke previews."""
from dataclasses import replace
from itertools import product

import numpy as np
import pytest

from resectionlab.core import array_digest
from resectionlab.geometry import AccessWindow, ToolGeometry
from resectionlab.native_ingress import IngressCandidate, screen_axis_accesses
from resectionlab.native_proposals import NominalCavityProposalConfig, PreparedNominalCavityProposer
from resectionlab.native_resection import NativeResectionConfig, NativeResectionEngine


TOOLS = (ToolGeometry("narrow", .7, .2, 16., 35., 1.),
         ToolGeometry("broad", 1.2, .8, 16., 35., 1.5))


def exits(*, tissue=None, offsets=((0, 0),), affine=None, tools=TOOLS,
          max_candidates=96, entries=None, index_affine=None, frame_record=None):
    if tissue is None:
        tissue = np.zeros((13, 13, 13), bool)
        tissue[4:9, 4:9, 4:9] = True
    affine = np.eye(4) if affine is None else affine
    original = affine if index_affine is None else index_affine
    nominal = np.zeros(tissue.shape, np.float32)
    nominal[5:8, 5:8, 5:8] = .75
    result = []
    for axis, sign in product(range(3), (-1, 1)):
        point = np.array([6., 6., 6.])
        point[axis] = 3.25 if sign == -1 else 8.75
        if entries and (axis, sign) in entries:
            point = np.array(entries[axis, sign], float)
        normal = -sign * original[:3, axis] / np.linalg.norm(original[:3, axis])
        access = AccessWindow(original[:3, :3] @ point + original[:3, 3], normal, 5.)
        config = NativeResectionConfig(tissue, np.zeros(tissue.shape, np.int16), affine,
            access, tools, "analytical-permitted-source", "analytical support only")
        proposer = PreparedNominalCavityProposer(config, nominal,
            nominal_provenance={"source_hash": config.source_hash,
                "nominal_target_hash": array_digest(nominal), "source_kind": "supplied_annotation",
                "derivation": "explicit analytical nominal"},
            config=NominalCavityProposalConfig(offsets, max_candidates),
            index_affine=index_affine, index_frame_record=frame_record)
        result.append(IngressCandidate(axis, sign, 3., NativeResectionEngine(config), proposer))
    return result


def test_six_labels_cannot_disguise_one_physical_access():
    actual = exits()[0]
    mislabeled = [replace(actual, axis=axis, outward_sign=sign,
        distance_mm=1. if (axis, sign) == (2, 1) else 3.)
        for axis, sign in product(range(3), (-1, 1))]
    result = screen_axis_accesses(mislabeled)
    assert result.status == "failed", result.to_dict()
    assert result.selected_exit is None and not result.complete


def test_opposite_metadata_sign_is_not_the_screened_access():
    candidates = exits()
    candidates[0], candidates[1] = (
        replace(candidates[1], outward_sign=-1), replace(candidates[0], outward_sign=1))
    result = screen_axis_accesses(candidates)
    assert result.status == "failed", result.to_dict()
    assert result.selected_exit is None
