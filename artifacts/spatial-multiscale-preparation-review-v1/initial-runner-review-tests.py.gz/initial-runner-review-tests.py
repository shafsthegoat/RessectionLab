"""Analytical and mocked integration only; no patient arrays or native runs."""
import hashlib
import io
from pathlib import Path
import subprocess
import sys
import tarfile

import numpy as np
import pytest

from scripts import diagnose_training_observation_coverage as diagnostic
from resectionlab.native_resection import NativeResectionEngine


def test_lost_preview_observer_cannot_silently_continue_to_another_case(monkeypatch):
    bodies = []
    def preview(self=None):
        bodies.append("entered")
    monkeypatch.setattr(NativeResectionEngine, "preview_stroke", preview)
    with diagnostic.InitialInventoryGuard(lambda: None) as guard:
        guard.begin_case("sub-PAT05")
        guard.case_calls = diagnostic.SETTINGS["max_initial_previews_per_case"]
        with pytest.raises(RuntimeError):
            preview()
        assert bodies == []
        with pytest.raises(RuntimeError):
            guard.begin_case("sub-PAT22")
            preview()
    assert bodies == []


def test_release_commit_must_match_archived_commit_before_data_access(tmp_path, monkeypatch):
    source = b"# tiny analytical source\n"
    archive = tmp_path / "source.tar"
    with tarfile.open(archive, "w", format=tarfile.PAX_FORMAT, pax_headers={"comment":"a"*40}) as stream:
        member = tarfile.TarInfo("source.py"); member.size = len(source)
        stream.addfile(member, io.BytesIO(source))
    monkeypatch.setattr(diagnostic, "ROOT", tmp_path)
    monkeypatch.setattr(diagnostic, "source_inventory", lambda:{"source.py":hashlib.sha256(source).hexdigest()})
    release = {"version":diagnostic.RELEASE_VERSION,"authorized":True,"manifest_sha256":"0"*64,
               "runtime_root":str(tmp_path),"source_commit":"b"*40,"source_archive":str(archive),
               "source_archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest()}
    with pytest.raises(ValueError):
        diagnostic.validate_release(release,"0"*64)


def test_cold_geometry_helper_import_is_not_optimizer_execution():
    code = '''from scripts import diagnose_training_observation_coverage as diagnostic
import sys
assert 'torch' not in sys.modules
with diagnostic.InitialInventoryGuard(lambda: None):
    from resectionlab.spatial_policy import world_to_sample_grid
'''
    result = subprocess.run([sys.executable,"-c",code],cwd=Path(__file__).resolve().parents[1],
                            text=True,capture_output=True,timeout=30)
    assert result.returncode == 0, result.stderr


def test_fractional_sample_coverage_and_center_cell_intervals_remain_distinct():
    affine = np.array([[0.,-3.,0.,17.],[-2.,0.,0.,-21.],[0.,0.,4.,6.],[0.,0.,0.,1.]])
    first = (affine @ [-1.,1.,1.,1.])[:3]
    last = (affine @ [3.,1.,1.,1.])[:3]
    coverage = np.full((6,3,3,3),.25)
    coverage[4:] = 0
    result = diagnostic.segment_visibility(first,last,affine,(3,3,3),coverage)
    assert result["sample_inside_center_domain"] == [False,True,True,True,False]
    assert result["continuous_center_domain_fraction"] == pytest.approx(.5,abs=1e-12)
    assert result["continuous_fullcell_extent_fraction"] == pytest.approx(.75,abs=1e-12)
    samples = np.asarray(result["sample_channel_coverage_fraction"])
    np.testing.assert_array_equal(samples[[0,4]],0)
    np.testing.assert_allclose(samples[1:4,:4],.25,rtol=0,atol=1e-12)
    np.testing.assert_array_equal(samples[:,4:],0)


@pytest.mark.parametrize("subject", ["sub-PAT16","sub-PAT20","sub-PAT26","sub-PAT27","sub-PAT29","sub-PAT31"])
def test_blocked_or_nontraining_case_rejected_before_check_or_decode(subject):
    def forbidden():
        pytest.fail("Rejected member must not reach loader/check callback")
    with pytest.raises(ValueError):
        diagnostic.load_initial(subject,{}, {},forbidden)


def test_union_intervals_merge_overlap_without_double_counting():
    assert diagnostic._union_length([[0.,.7],[.2,.8],None]) == pytest.approx(.8)
    assert diagnostic._union_length([[0.,.2],[.8,1.]]) == pytest.approx(.4)
    assert diagnostic._union_length([None,None]) == 0
