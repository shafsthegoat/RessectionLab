"""Independent mocked budget controls; no native geometry, patient or policy run."""
from types import SimpleNamespace

import pytest

import resectionlab.planning_budget as module
from resectionlab.planning_budget import PlanningBudget, PlanningBudgetViolation


class Clock:
    def __init__(self):
        self.value = 0.

    def __call__(self):
        return self.value


def fake_engine():
    calls = []
    class Engine:
        def preview_stroke(self, label):
            calls.append(label)
            return SimpleNamespace(feasible=True, reason="", microsteps=())
    return Engine, calls


def test_deleted_inherited_instrumentation_restores_exception_and_releases_scope():
    base, _ = fake_engine()
    class Child(base):
        pass
    guard = PlanningBudget(Child, _clock=Clock())
    caught = None
    try:
        with guard:
            Child().preview_stroke("first")
            del Child.preview_stroke
    except BaseException as error:
        caught = error
    try:
        assert module._active_guard is None, "failed cleanup leaked the process-exclusive budget"
        assert isinstance(caught, PlanningBudgetViolation), repr(caught)
        assert guard.snapshot()["native_preview_entries"] is None
        assert "preview_stroke" not in vars(Child)
        with PlanningBudget(base, _clock=Clock()) as fresh:
            base().preview_stroke("separate later arm")
            fresh.complete(history_complete=True)
    finally:
        # Keep the intentionally broken pre-repair control from poisoning pytest.
        if module._active_guard is guard:
            module._active_guard = None
