# Explicit-reference spatial frame V2

This separate research revision addresses the V1
[conditioning counterexample](../artifacts/native-spatial-feature-independent-v1/conditioning-counterexample.json).
V1, its failed invariance case and every original receipt remain unchanged.
Tests and the algebraic probe are pending release of the numerical-work hold.
There is no production input profile, patient experiment or learned policy.

The caller supplies a `DeclaredTangent`: a physical reference vector, source hash,
coordinate-frame label and declaration identifier. The frame constructor requires
matching source and coordinate identities for the access geometry. It does not
infer an axis from the source affine and never falls back to another reference.
This checks metadata consistency; it does not authenticate an external source or
provide a universal tangent convention across patients.

Normalize the inward normal and tangent reference after scaling by their largest
component. Use their cross product to measure the tangent sine and construct the
second tangent; a second cross product supplies the first. Require sine greater
than `0.1 + 64 × float64 epsilon`. Values below the conditioning limit or inside
the inclusive roundoff rejection band fail with a receipt containing the actual
reference, normalized normal, measured sine and reason. Accepted frames record
the same inputs and their normalization factor, which is less than 10.

The 0.1 condition is a declared engineering limit, not a clinical angle rule.
The roundoff band is a conservative engineering margin, not a rigorous global
floating-point error interval. It prevents automatic axis switching because
there is no selection branch. Coordinate transformations must transport the
explicit reference alongside points, access center and normal. No unconditional
accuracy or acceptance guarantee at arbitrary floating-point boundaries is
claimed.

The tests target the exact saved proper-rotation counterexample: a declared
well-conditioned Y reference should remain consistent, while the ill-conditioned
X reference should reject both before and after rotation. They also cover the
rejection band, source/frame mismatch, missing references, positive direction
rescaling, translation/RAS-to-LPS, row permutation and source reindexing with a
preserved physical reference. Source reindexing must not silently redefine the
reference.

Candidate coordinates and the eight volume/centroid values reuse V1's pure
descriptor functions. The summary collision stays explicit. Partial-contact
history, current tool, remaining action budget, detailed geometry, topology and
candidate interactions remain missing or compressed. V2 makes no Markov-state
claim and does not resolve those limitations. Input scaling and actor/critic
changes would need separate declarations before any learned experiment.

Implementation: `research/native_spatial_features_v2.py`; focused checks:
`tests/test_native_spatial_features_v2.py`; algebra-only probe:
`scripts/probe_native_spatial_features_v2.py`. The probe reads frozen V1 synthetic
coordinates and the independent numerical counterexample, constructs no simulator
or policy, and performs no new native transitions or gradients. Independent review
is required after the focused checks pass.
